<div class="ban-bottom-w3l" >
	<div class="container">

		<div class="row">
			<div class="col-md-10 col-md-offset-1">
				<div class="panel panel-default">
				  	<div class=" c_header">
				    	<h3 class="panel-title "><?= ucfirst($event->title)?></h3>
				  	</div>
				  	<div class="panel-body" style="text-align: left; font-style: justify;">
				    	<p>
				    		<?= ucfirst($event->description); ?>
				    	</p>
				  	</div>
				</div>

			</div>
		</div>
	</div>
</div>